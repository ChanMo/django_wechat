#!/usr/bin/python
# vim: set fileencoding=utf-8 :
from django.apps import AppConfig

class WechatConfig(AppConfig):
    name = u'wechat'
    verbose_name = u'微信'
