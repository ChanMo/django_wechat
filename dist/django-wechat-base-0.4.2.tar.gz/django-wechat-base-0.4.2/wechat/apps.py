from django.utils.translation import ugettext_lazy as _
from django.apps import AppConfig

class WechatConfig(AppConfig):
    name = 'wechat'
    verbose_name = _('wechat')
