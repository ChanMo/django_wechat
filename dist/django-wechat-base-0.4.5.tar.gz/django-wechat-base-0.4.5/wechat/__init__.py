default_app_config = 'wechat.apps.WechatConfig'

